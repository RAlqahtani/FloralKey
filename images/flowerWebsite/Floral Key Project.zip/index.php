<!DOCTYPE html>
<html>
<head>
    <title> FloralKey.com </title>
    <link rel="html" href="C:\Users\ragha\Desktop\flower website\html.html"> 

</head>
<body>
<script type = "text/javascript">
    alert ( " Welcome to Floral Key ! " )
</script>
</body>

</html>


