<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FloralKey.com</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="Style.css">

</head>
<!-- code php -->
<body>
    <?php 
 include 'index.php' ;
 ?>


<!-- header section starts  -->



<header>

    <input type="checkbox" name="" id="toggler">
    <label for="toggler" class="fas fa-bars"></label>

    <a href="#" class="logo">Floral Key <span>.</span></a>

    <nav class="navbar">
        <a href="#home">home</a>
        <a href="#Flower">Flower</a>
        <a href="#Ideas">Ideas</a>
    </nav>

 

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

    <div class="content">
        <h3>Floral Key</h3>
        <span> Flowers more than words </span>
        <p>Certain flowers are associated with certain months, thus, this website will cover some of our special flowers, give you more details about them and best flower selection and ideas.</p>
     </div>
    
</section>

<!-- home section ends -->

<!-- about section starts  -->

<section class="Flower" id="Flower">

    <h1 class="heading"> unique<span> Flower </span></h1>

    <div class="row">

        <div class="video-container">
            <video src="images\Video.mp4" loop autoplay muted></video>
            
        </div>

        <div class="content">
            <h3>Do you know that each month has a special flower? </h3>
    
            <p>Many people don't know that there's actually a birth flower too which has its own special meaning! Knowing all about birth flower meanings can come in very handy when choosing the perfect birthday flowers to send someone. So here's our guide on every month's birth flower and what characteristics go along with them!</p>
            <a href="html2.html" class="btn">Find yours</a>

        </div>

    </div>

</section>

<!-- about section ends -->

<!-- icons section starts  -->

<section class="icons-container">

    <div class="icons" style="height:200px;">
        <img src="images\13.jpg" alt="">
        
    </div>
    <div class="content">
        <h8>" After women, flowers are the most lovely thing God has given the world"</h8>
            <p>Flowers always make people better, happier, and more helpful they are sunshine, food and medicine for the soul.</p>
    </div>
   
</section>

<!-- icons section ends -->

<!-- prodcuts section starts  -->

<section class="Ideas" id="Ideas">
    
        
    <h1 class="heading"> Some <span>Ideas</span> </h1>
    
        



    <div class="box-container">
       
        <div class="box">
            <div class="image">
                <img src="images\imag 1.avif" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Artistic Touch</h3>
                 
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images\imag 2.avif" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Double Your Love</h3>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images\imag 3.avif" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Mon Amour</h3>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images\imag 4.avif" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Magic Lilium</h3>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images\imag 5.avif" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Pure Heart</h3>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images\image 6.avif" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Guardian Angel</h3>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images\imag 7.avif" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Pink Lady</h3>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images\imag 8.avif" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Crazy In Love</h3>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images\imag 9.avif" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Piece Of Art</h3>

            </div>
        </div>

    </div>

</section>

<!-- prodcuts section ends -->




<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="htmlPage.php#home">home</a>
            <a href="htmlPage.php#Flower">Flower</a>
            <a href="htmlPage.php#Ideas">Ideas</a>
        </div>


        <div class="box">
            <h3>locations</h3>
            <a href="#">KSU,Saudi Arabia</a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a href="#">+966-9999966666</a>
            <a href="#">442@student.ksu.edu.sa</a>
            <a href="#">KSU, Riyadh - Saudi Arabia</a>
            <img src="/images/payment.png" alt="">
        </div>

    </div>

    <div class="credit"> created by <span>  Raghad AL Qahtani, Ghadeer , Raghad AL Zahrani , Salma , Amani</span> </div>

    
</section>
<!-- footer section ends -->   
</body>
</html>